let player;
let playerSize = 30;
let playerSpeed = 5;
let playerX, playerY;

let items = [];
let numItems = 5;
let itemSize = 20;

let score = 0;
let environment = 'campo'; // Pode ser 'campo' ou 'cidade'
let timer = 30; // Tempo em segundos
let gameStarted = false;
let gameOver = false;

let campoColor = { r: 124, g: 252, b: 0 }; // Verde grama
let cidadeColor = { r: 100, g: 100, b: 100 }; // Cinza urbano

// Imagens para os itens (seriam carregadas aqui)
let itemCampoImg; // Ex: uma maçã, uma flor
let itemCidadeImg; // Ex: uma chave, um celular

function preload() {
  // Substitua 'caminho/para/imagem_campo.png' e 'caminho/para/imagem_cidade.png'
  // pelas URLs ou caminhos reais das suas imagens.
  // Você pode encontrar ícones gratuitos em sites como Flaticon ou The Noun Project.
  // Certifique-se de que as imagens estejam na mesma pasta do seu sketch ou forneça o caminho correto.
  // Por exemplo:
  // itemCampoImg = loadImage('assets/flor.png');
  // itemCidadeImg = loadImage('assets/chave.png');
}

function setup() {
  createCanvas(800, 600);
  playerX = width / 2;
  playerY = height / 2;
  spawnItems();
  setInterval(countdown, 1000); // Decrementa o tempo a cada segundo
}

function draw() {
  if (!gameStarted) {
    drawStartScreen();
  } else if (gameOver) {
    drawGameOverScreen();
  } else {
    drawEnvironment();
    drawPlayer();
    drawItems();
    checkCollisions();
    displayScoreAndTime();
  }
}

function drawStartScreen() {
  background(50);
  fill(255);
  textAlign(CENTER);
  textSize(40);
  text("Cidade vs. Campo: A Coleta!", width / 2, height / 2 - 50);
  textSize(20);
  text("Colete itens específicos de cada ambiente.", width / 2, height / 2);
  text("Pressione ESPAÇO para começar e alternar ambientes.", width / 2, height / 2 + 50);
}

function drawGameOverScreen() {
  background(50);
  fill(255);
  textAlign(CENTER);
  textSize(40);
  text("Fim de Jogo!", width / 2, height / 2 - 50);
  textSize(30);
  text("Sua Pontuação: " + score, width / 2, height / 2);
  textSize(20);
  text("Pressione 'R' para Reiniciar", width / 2, height / 2 + 50);
}

function drawEnvironment() {
  if (environment === 'campo') {
    background(campoColor.r, campoColor.g, campoColor.b);
    // Adicionar elementos visuais do campo (montanhas simples, árvores)
    fill(139, 69, 19); // Marrom para o tronco
    rect(width * 0.1, height * 0.6, 20, 50);
    fill(0, 100, 0); // Verde para a copa
    ellipse(width * 0.1 + 10, height * 0.6, 60, 60);

    fill(139, 69, 19); // Marrom para o tronco
    rect(width * 0.8, height * 0.7, 20, 50);
    fill(0, 100, 0); // Verde para a copa
    ellipse(width * 0.8 + 10, height * 0.7, 60, 60);

  } else {
    background(cidadeColor.r, cidadeColor.g, cidadeColor.b);
    // Adicionar elementos visuais da cidade (prédios simples)
    fill(150); // Cinza para os prédios
    rect(width * 0.1, height * 0.4, 80, height * 0.4);
    rect(width * 0.3, height * 0.5, 60, height * 0.3);
    rect(width * 0.7, height * 0.3, 70, height * 0.5);

    fill(0); // Janelas
    rect(width * 0.1 + 10, height * 0.5, 15, 20);
    rect(width * 0.1 + 40, height * 0.5, 15, 20);
    rect(width * 0.3 + 10, height * 0.6, 15, 20);
  }
}

function drawPlayer() {
  fill(255, 0, 0); // Vermelho para o jogador
  ellipse(playerX, playerY, playerSize, playerSize);

  // Movimento do jogador
  if (keyIsDown(LEFT_ARROW)) {
    playerX -= playerSpeed;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    playerX += playerSpeed;
  }
  if (keyIsDown(UP_ARROW)) {
    playerY -= playerSpeed;
  }
  if (keyIsDown(DOWN_ARROW)) {
    playerY += playerSpeed;
  }

  // Limitar o jogador à tela
  playerX = constrain(playerX, playerSize / 2, width - playerSize / 2);
  playerY = constrain(playerY, playerSize / 2, height - playerSize / 2);
}

function spawnItems() {
  items = []; // Limpa os itens existentes
  for (let i = 0; i < numItems; i++) {
    let itemType = random(['campo', 'cidade']);
    items.push({
      x: random(itemSize / 2, width - itemSize / 2),
      y: random(itemSize / 2, height - itemSize / 2),
      type: itemType
    });
  }
}

function drawItems() {
  for (let item of items) {
    if (item.type === 'campo') {
      fill(0, 200, 0); // Verde para item do campo
      // Se tiver imagem, use image(itemCampoImg, item.x - itemSize/2, item.y - itemSize/2, itemSize, itemSize);
    } else {
      fill(255, 200, 0); // Amarelo para item da cidade
      // Se tiver imagem, use image(itemCidadeImg, item.x - itemSize/2, item.y - itemSize/2, itemSize, itemSize);
    }
    ellipse(item.x, item.y, itemSize, itemSize);
  }
}

function checkCollisions() {
  for (let i = items.length - 1; i >= 0; i--) {
    let item = items[i];
    let d = dist(playerX, playerY, item.x, item.y);
    if (d < playerSize / 2 + itemSize / 2) {
      if (item.type === environment) {
        score++;
        items.splice(i, 1); // Remove o item coletado
        if (items.length === 0) {
          spawnItems(); // Gera novos itens quando todos são coletados
        }
      } else {
        score = max(0, score - 1); // Penalidade por coletar item errado
      }
    }
  }
}

function displayScoreAndTime() {
  fill(0);
  textSize(20);
  textAlign(LEFT);
  text("Pontos: " + score, 10, 25);
  text("Tempo: " + timer, 10, 50);
  text("Ambiente: " + (environment === 'campo' ? 'Campo' : 'Cidade'), 10, 75);
}

function keyPressed() {
  if (!gameStarted && keyCode === 32) { // ESPAÇO
    gameStarted = true;
    timer = 30;
    score = 0;
    gameOver = false;
    spawnItems();
  } else if (gameStarted && keyCode === 32) { // ESPAÇO para alternar ambiente
    environment = (environment === 'campo' ? 'cidade' : 'campo');
    spawnItems(); // Gera novos itens ao mudar de ambiente
  } else if (gameOver && key === 'r' || key === 'R') {
    resetGame();
  }
}

function countdown() {
  if (gameStarted && !gameOver) {
    timer--;
    if (timer <= 0) {
      gameOver = true;
    }
  }
}

function resetGame() {
  gameStarted = false;
  gameOver = false;
  timer = 30;
  score = 0;
  playerX = width / 2;
  playerY = height / 2;
  environment = 'campo';
  items = [];
}